package com.threadplay.app

import org.json.JSONArray
import org.json.JSONObject

data class Post(val author: String, val text: String, val timestamp: Long = System.currentTimeMillis(), val isBot: Boolean = false)
data class ThreadProfile(
    val premise: String = "",
    val characters: String = "",
    val botStyle: String = "Interpreta a los personajes de forma consistente. Escribe como una persona que participa en un roleplay, no como un asistente.",
    val memory: String = "",
    val styleNotes: String = ""
)
data class RoleThread(
    val id: Long,
    val title: String,
    val profile: ThreadProfile = ThreadProfile(),
    val posts: List<Post> = emptyList()
)

fun encodeThreads(threads: List<RoleThread>): String {
    val arr = JSONArray()
    threads.forEach { t ->
        val profile = JSONObject()
            .put("premise", t.profile.premise)
            .put("characters", t.profile.characters)
            .put("botStyle", t.profile.botStyle)
            .put("memory", t.profile.memory)
            .put("styleNotes", t.profile.styleNotes)
        val posts = JSONArray()
        t.posts.forEach { p ->
            posts.put(JSONObject().put("author", p.author).put("text", p.text)
                .put("timestamp", p.timestamp).put("isBot", p.isBot))
        }
        arr.put(JSONObject().put("id", t.id).put("title", t.title).put("profile", profile).put("posts", posts))
    }
    return arr.toString()
}

fun decodeThreads(raw: String): List<RoleThread> = try {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val pr = o.optJSONObject("profile") ?: JSONObject()
        val pa = o.optJSONArray("posts") ?: JSONArray()
        val posts = (0 until pa.length()).map { j ->
            val p = pa.getJSONObject(j)
            Post(p.optString("author"), p.optString("text"), p.optLong("timestamp"), p.optBoolean("isBot"))
        }
        RoleThread(o.getLong("id"), o.getString("title"),
            ThreadProfile(pr.optString("premise"), pr.optString("characters"),
                pr.optString("botStyle", "Interpreta personajes de forma consistente."),
                pr.optString("memory"), pr.optString("styleNotes")), posts)
    }
} catch (_: Exception) { emptyList() }
