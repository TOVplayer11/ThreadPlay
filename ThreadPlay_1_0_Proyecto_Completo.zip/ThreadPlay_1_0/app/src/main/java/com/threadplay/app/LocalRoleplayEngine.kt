package com.threadplay.app

import android.content.Context
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Runs a LiteRT-LM model stored locally. No network requests are made.
 * Import a compatible .litertlm model from Settings before enabling AI.
 */
class LocalRoleplayEngine(private val context: Context) {
    private var engine: Engine? = null
    private val modelFile = File(context.filesDir, "models/roleplay.litertlm")

    fun hasModel(): Boolean = modelFile.exists() && modelFile.length() > 0

    suspend fun installModel(source: android.net.Uri) = withContext(Dispatchers.IO) {
        val folder = modelFile.parentFile!!
        folder.mkdirs()
        context.contentResolver.openInputStream(source).use { input ->
            requireNotNull(input) { "No se pudo abrir el archivo seleccionado." }
            modelFile.outputStream().use { output -> input.copyTo(output) }
        }
        engine?.close()
        engine = null
    }

    suspend fun reply(thread: RoleThread, maxChars: Int, temperature: Float): String =
        withContext(Dispatchers.IO) {
            check(hasModel()) { "Primero importa un modelo .litertlm desde Ajustes." }
            if (engine == null) {
                engine = Engine(EngineConfig(modelPath = modelFile.absolutePath))
                engine!!.initialize()
            }
            val recent = thread.posts.takeLast(18)
            val styleExamples = recent.filter { !it.isBot }.takeLast(4).joinToString("\n") { it.text }
            val system = """
                Eres un compañero de roleplay narrativo. No eres un asistente ni debes explicar lo que haces.
                Continúa la escena como participante: interpreta a los personajes que no controla el usuario,
                aporta reacciones y pequeños acontecimientos coherentes, conserva sus voces y evita decidir
                acciones, pensamientos o diálogos del personaje del usuario.

                REGLAS DE FORMATO:
                - Devuelve exactamente UNA publicación breve, con máximo $maxChars caracteres.
                - No escribas etiquetas como "Bot:" ni expliques las reglas.
                - Puedes usar acciones narrativas entre asteriscos y diálogos entre comillas.
                - No repitas la publicación del usuario ni resumas toda la escena.
                - Mantén continuidad y deja espacio para que el usuario responda.

                PREMISA:
                ${thread.profile.premise}
                PERSONAJES:
                ${thread.profile.characters}
                ESTILO DEL BOT:
                ${thread.profile.botStyle}
                MEMORIA DE ESTE HILO:
                ${thread.profile.memory}
                NOTAS DE ESTILO DEL USUARIO (adaptación por ejemplos, no entrenamiento):
                ${thread.profile.styleNotes}
                EJEMPLOS RECIENTES DE ESCRITURA DEL USUARIO:
                $styleExamples
            """.trimIndent()
            val initial = recent.map { p ->
                if (p.isBot) Message.model(p.text) else Message.user(p.text)
            }
            val config = ConversationConfig(
                systemInstruction = Contents.of(system),
                initialMessages = initial,
                samplerConfig = SamplerConfig(topK = 32, topP = 0.9, temperature = temperature),
                maxOutputToken = 160
            )
            val conversation = engine!!.createConversation(config)
            try {
                val response = conversation.sendMessage("Continúa el roleplay con una sola publicación.")
                val raw = response.text.trim()
                raw.take(maxChars).trim()
            } finally {
                conversation.close()
            }
        }

    fun close() { engine?.close(); engine = null }
}
