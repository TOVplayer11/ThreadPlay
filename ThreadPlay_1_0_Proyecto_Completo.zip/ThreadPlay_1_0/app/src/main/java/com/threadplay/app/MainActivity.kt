package com.threadplay.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Ink = Color(0xFF17112F)
private val Purple = Color(0xFF8242DD)
private val Pink = Color(0xFFD85BCB)
private val Paper = Color(0xFFF7F3FF)
private const val POST_LIMIT = 280

class MainActivity : ComponentActivity() {
    private lateinit var ai: LocalRoleplayEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ai = LocalRoleplayEngine(this)
        val prefs = getSharedPreferences("threadplay_private", MODE_PRIVATE)
        setContent {
            var threads by remember { mutableStateOf(decodeThreads(prefs.getString("threads", "[]") ?: "[]")) }
            var selectedId by remember { mutableStateOf<Long?>(null) }
            var draft by remember { mutableStateOf("") }
            var postsPerTurn by remember { mutableIntStateOf(1) }
            var newTitle by remember { mutableStateOf("") }
            var showCreate by remember { mutableStateOf(false) }
            var showSettings by remember { mutableStateOf(false) }
            var showProfile by remember { mutableStateOf(false) }
            var busy by remember { mutableStateOf(false) }
            var status by remember { mutableStateOf(if (ai.hasModel()) "Modelo local detectado" else "Falta importar el modelo local") }
            var temperature by remember { mutableFloatStateOf(0.85f) }
            val scope = rememberCoroutineScope()

            fun save(updated: List<RoleThread>) {
                threads = updated
                prefs.edit().putString("threads", encodeThreads(updated)).apply()
            }
            fun updateThread(updated: RoleThread) = save(threads.map { if (it.id == updated.id) updated else it })

            val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                if (uri != null) {
                    scope.launch {
                        busy = true
                        status = "Copiando modelo al almacenamiento privado..."
                        try {
                            ai.installModel(uri)
                            status = "Modelo importado. Reinicia la app si no carga."
                        } catch (e: Exception) { status = "Error al importar: ${e.message}" }
                        busy = false
                    }
                }
            }

            MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Pink, background = Paper, surface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Paper) {
                    val thread = threads.firstOrNull { it.id == selectedId }
                    when {
                        showSettings -> SettingsScreen(status, ai.hasModel(), temperature,
                            onTemperature = { temperature = it },
                            onImport = { modelPicker.launch(arrayOf("*/*")) },
                            onBack = { showSettings = false })
                        thread != null -> ThreadScreen(
                            thread = thread, draft = draft, onDraft = { draft = it },
                            postsPerTurn = postsPerTurn, onCount = { postsPerTurn = it },
                            busy = busy, status = status,
                            onBack = { selectedId = null; draft = "" },
                            onProfile = { showProfile = true },
                            onSend = {
                                if (draft.isNotBlank() && !busy) {
                                    val pieces = splitIntoPosts(draft, postsPerTurn)
                                    val userPosts = pieces.map { Post("Tú", it, isBot = false) }
                                    val updated = thread.copy(posts = thread.posts + userPosts)
                                    updateThread(updated)
                                    draft = ""
                                    if (ai.hasModel()) {
                                        scope.launch {
                                            busy = true
                                            status = "El bot está escribiendo..."
                                            try {
                                                val answer = ai.reply(updated, POST_LIMIT, temperature)
                                                val botPost = Post("ThreadPlay", answer, isBot = true)
                                                updateThread(updated.copy(posts = updated.posts + botPost))
                                                status = "Respuesta generada sin conexión"
                                            } catch (e: Exception) {
                                                status = "No se pudo generar: ${e.message}"
                                            }
                                            busy = false
                                        }
                                    } else status = "Tus publicaciones se guardaron. Importa un modelo para activar respuestas."
                                }
                            }
                        )
                        else -> HomeScreen(threads, onNew = { showCreate = true },
                            onOpen = { selectedId = it }, onSettings = { showSettings = true },
                            onDelete = { id -> save(threads.filterNot { it.id == id }) })
                    }

                    if (showCreate) {
                        AlertDialog(onDismissRequest = { showCreate = false },
                            title = { Text("Crear hilo") },
                            text = { OutlinedTextField(newTitle, { newTitle = it }, label = { Text("Nombre del roleplay") }) },
                            confirmButton = { TextButton(onClick = {
                                val id = System.currentTimeMillis()
                                save(listOf(RoleThread(id, newTitle.trim().ifBlank { "Nuevo hilo" })) + threads)
                                selectedId = id; newTitle = ""; showCreate = false
                            }) { Text("Crear") } },
                            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancelar") } })
                    }
                    if (showProfile && thread != null) {
                        ProfileDialog(thread, onDismiss = { showProfile = false }, onSave = {
                            updateThread(it); showProfile = false
                        })
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        if (::ai.isInitialized) ai.close()
        super.onDestroy()
    }
}

@Composable
private fun HomeScreen(threads: List<RoleThread>, onNew: () -> Unit, onOpen: (Long) -> Unit,
                       onSettings: () -> Unit, onDelete: (Long) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("ThreadPlay", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Ink)
                Text("Roleplay sin límites · privado · offline", color = Purple, fontSize = 12.sp)
            }
            Text("⚙", fontSize = 25.sp, modifier = Modifier.clickable { onSettings() })
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("+ Nuevo hilo") }
        Spacer(Modifier.height(12.dp))
        if (threads.isEmpty()) Text("Tus historias aparecerán aquí. Crea el primer hilo.", color = Ink)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(threads) { t ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { onOpen(t.id) }) {
                            Text(t.title, fontWeight = FontWeight.Bold, color = Ink)
                            Text("${t.posts.size} publicaciones · ${t.profile.characters.ifBlank { "Sin personajes configurados" }}",
                                color = Purple, fontSize = 11.sp, maxLines = 1)
                        }
                        Text("×", fontSize = 22.sp, color = Color.Gray, modifier = Modifier.clickable { onDelete(t.id) }.padding(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ThreadScreen(thread: RoleThread, draft: String, onDraft: (String) -> Unit,
                         postsPerTurn: Int, onCount: (Int) -> Unit, busy: Boolean, status: String,
                         onBack: () -> Unit, onProfile: () -> Unit, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Ink).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", color = Color.White, fontSize = 28.sp, modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
            Column(Modifier.weight(1f)) {
                Text(thread.title, color = Color.White, fontWeight = FontWeight.Bold)
                Text("Hilo independiente", color = Color(0xFFDCCBFF), fontSize = 11.sp)
            }
            Text("✎", color = Color.White, fontSize = 21.sp, modifier = Modifier.clickable { onProfile() }.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(thread.posts) { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (p.isBot) Arrangement.Start else Arrangement.End) {
                    Card(Modifier.fillMaxWidth(0.91f), shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = if (p.isBot) Color.White else Color(0xFFECE2FF))) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.author, color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(p.text, color = Ink, fontSize = 14.sp)
                            Text("${p.text.length}/$POST_LIMIT", color = Color.Gray, fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.End))
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(Color.White).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Tus publicaciones por turno:", fontSize = 11.sp, color = Purple, modifier = Modifier.weight(1f))
                (1..3).forEach { n ->
                    FilterChip(selected = postsPerTurn == n, onClick = { onCount(n) }, label = { Text("$n") })
                    Spacer(Modifier.width(4.dp))
                }
            }
            OutlinedTextField(value = draft, onValueChange = { if (it.length <= POST_LIMIT * 3) onDraft(it) },
                modifier = Modifier.fillMaxWidth(), minLines = 2, placeholder = { Text("Escribe tu publicación...") },
                supportingText = { Text("${draft.length}/840 caracteres · máximo 3 publicaciones") })
            Button(onClick = onSend, enabled = draft.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "El bot está escribiendo..." else "Publicar y recibir respuesta")
            }
            Text(status, color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SettingsScreen(status: String, hasModel: Boolean, temperature: Float, onTemperature: (Float) -> Unit,
                           onImport: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("‹ Volver", color = Purple, modifier = Modifier.clickable { onBack() })
        Spacer(Modifier.height(12.dp))
        Text("Ajustes", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(16.dp))
        Text("Motor de IA local", fontWeight = FontWeight.Bold)
        Text(if (hasModel) "Modelo instalado" else "No hay modelo instalado", color = Purple)
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("Importar modelo .litertlm") }
        Text("Selecciona un archivo compatible que ya tengas en el dispositivo. La importación se hace localmente.",
            fontSize = 12.sp, color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        Text("Creatividad: ${(temperature * 100).toInt()}%")
        Slider(value = temperature, onValueChange = onTemperature, valueRange = 0.45f..1.15f)
        Spacer(Modifier.height(12.dp))
        Text("Estado: $status", fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        Text("Privacidad: las conversaciones se guardan en el almacenamiento privado de esta app. No se solicitan permisos de Internet.",
            fontSize = 12.sp, color = Ink)
    }
}

@Composable
private fun ProfileDialog(thread: RoleThread, onDismiss: () -> Unit, onSave: (RoleThread) -> Unit) {
    var premise by remember { mutableStateOf(thread.profile.premise) }
    var characters by remember { mutableStateOf(thread.profile.characters) }
    var style by remember { mutableStateOf(thread.profile.botStyle) }
    var memory by remember { mutableStateOf(thread.profile.memory) }
    var styleNotes by remember { mutableStateOf(thread.profile.styleNotes) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Configuración del hilo") },
        text = {
            Column(Modifier.heightIn(max = 480.dp)) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { OutlinedTextField(premise, { premise = it }, label = { Text("Premisa") }, minLines = 2) }
                    item { OutlinedTextField(characters, { characters = it }, label = { Text("Personajes y personalidades") }, minLines = 3) }
                    item { OutlinedTextField(style, { style = it }, label = { Text("Estilo de respuesta del bot") }, minLines = 2) }
                    item { OutlinedTextField(memory, { memory = it }, label = { Text("Memoria / acontecimientos importantes") }, minLines = 3) }
                    item { OutlinedTextField(styleNotes, { styleNotes = it }, label = { Text("Notas sobre tu estilo de escritura") }, minLines = 2) }
                }
            }
        },
        confirmButton = { TextButton(onClick = {
            onSave(thread.copy(profile = ThreadProfile(premise, characters, style, memory, styleNotes)))
        }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

private fun splitIntoPosts(text: String, desired: Int): List<String> {
    val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    val result = mutableListOf<String>()
    var current = ""
    for (word in words) {
        if ((current + " " + word).trim().length > POST_LIMIT) {
            if (current.isNotBlank()) result.add(current)
            current = word
        } else current = (current + " " + word).trim()
    }
    if (current.isNotBlank()) result.add(current)
    if (result.size <= desired) return result
    val merged = result.take(desired - 1) + result.drop(desired - 1).joinToString(" ")
    return merged.map { it.take(POST_LIMIT) }
}
