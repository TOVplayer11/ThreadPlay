# ThreadPlay 1.0 - proyecto fuente Android

## Funciones implementadas en el código
- Aplicación Android nativa en Kotlin + Jetpack Compose.
- Hilos separados, creación y eliminación.
- Posts con límite de 280 caracteres.
- Selector de 1, 2 o 3 posts del usuario por turno.
- Una respuesta del bot por turno, también limitada a 280 caracteres.
- Perfiles por hilo: premisa, personajes, estilo del bot, memoria y notas de estilo.
- Persistencia local privada mediante preferencias de la app.
- Importación local de un modelo `.litertlm`.
- Inferencia local mediante LiteRT-LM; no se usa API remota.
- Sin permiso INTERNET en AndroidManifest.

## Requisitos y limitaciones
- Requiere Android Studio, Android SDK 35 y conexión de desarrollo para descargar dependencias Gradle la primera vez.
- El uso normal de la app y la inferencia del modelo no necesitan conexión.
- El modelo no se incluye en el ZIP ni en el APK: es demasiado grande y debe importarse como archivo compatible.
- Este proyecto fuente no ha sido compilado ni probado en un Motorola E15. La compatibilidad real, memoria disponible, velocidad y estabilidad deben verificarse en el dispositivo.
- El código de inferencia sigue la API Kotlin de LiteRT-LM documentada por Google. La versión `latest.release` se resolverá al sincronizar Gradle y puede requerir ajustes si la API cambia.
- La adaptación de estilo se realiza mediante ejemplos recientes y notas guardadas por hilo (contexto del prompt), no mediante reentrenamiento del modelo.
- La memoria narrativa es editable por hilo; no hay resumen automático de memoria todavía.
- La división de mensajes intenta repartir hasta 3 publicaciones, con tope de 280 caracteres por publicación.

## Compilar el APK
1. Descomprime el ZIP.
2. Abre la carpeta `ThreadPlay_1_0` en Android Studio.
3. Sincroniza Gradle y espera a que se descarguen las dependencias.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio mostrará la ubicación del APK generado.

## Modelo local
Importa desde Ajustes un modelo `.litertlm` compatible con LiteRT-LM. El proyecto no descarga modelos, no necesita Internet durante el roleplay y no incluye un modelo propietario.
